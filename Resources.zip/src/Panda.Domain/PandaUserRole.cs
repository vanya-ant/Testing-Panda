﻿using Microsoft.AspNetCore.Identity;

namespace Panda.Domain
{
    public class PandaUserRole : IdentityRole
    {
    }
}
